from flask import Flask, render_template, request, redirect, url_for, flash
import pyodbc
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError

# Initialize Flask app
app = Flask(__name__)
app.secret_key = "your_secret_key"

# Initialize PasswordHasher
ph = PasswordHasher()

# Database connection
def get_db_connection():
    try:
        connection = pyodbc.connect(
            r"DRIVER={ODBC Driver 17 for SQL Server};"
            r"SERVER=JG-07\MSSQLSERVER2022;"  # Replace with your server name
            r"DATABASE=TimeSheet;"            # Replace with your database name
            r"Trusted_Connection=yes;"
        )
        return connection
    except Exception as e:
        print(f"Database connection failed: {e}")
        return None

# Insert user into the database
def insert_user(username, password_hash):
    try:
        connection = get_db_connection()
        with connection.cursor() as cursor:
            cursor.execute(
                "INSERT INTO users (username, password_hash) VALUES (?, ?)",
                username, password_hash
            )
            connection.commit()
        return True
    except:
        return False

# Fetch user from the database
def fetch_user(username):
    try:
        connection = get_db_connection()
        with connection.cursor() as cursor:
            cursor.execute(
                "SELECT password_hash FROM users WHERE username = ?",
                username
            )
            row = cursor.fetchone()
            return row[0] if row else None
    except:
        return None

# Password hashing functions
def hash_password(password):
    return ph.hash(password)

def verify_password(stored_hash, password):
    try:
        return ph.verify(stored_hash, password)
    except Exception:
        return False

# Routes
@app.route("/")
def home():
    return "<h1>Welcome to the Flask Authentication App</h1>"

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        hashed_password = hash_password(password)

        if insert_user(username, hashed_password):
            flash("Registration successful!", "success")
            return redirect(url_for("login"))
        else:
            flash("Username already exists.", "warning")
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        stored_hash = fetch_user(username)

        if stored_hash and verify_password(stored_hash, password):
            flash("Login successful!", "success")
            return redirect(url_for("dashboard"))
        else:
            flash("Invalid username or password.", "danger")
    return render_template("login.html")

@app.route("/dashboard")
def dashboard():
    return "<h1>Welcome to your Dashboard!</h1>"

if __name__ == "__main__":
    app.run(debug=True)
